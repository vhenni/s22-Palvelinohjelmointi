package s22.FirstHenni.web;

import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {

	@RequestMapping("index")
	@ResponseBody
	public String indexInfo () {
		return "This is the main page";
	}
	@RequestMapping("contact")
	@ResponseBody
	public String contactInfo () {
		return "This is the contact page";
	}
}
