package s22.FirstHenni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstHenniApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstHenniApplication.class, args);
	}

}
