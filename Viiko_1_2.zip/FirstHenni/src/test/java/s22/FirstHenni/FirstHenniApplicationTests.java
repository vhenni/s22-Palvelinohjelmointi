package s22.FirstHenni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstHenniApplicationTests {

	@Test
	void contextLoads() {
	}

}
