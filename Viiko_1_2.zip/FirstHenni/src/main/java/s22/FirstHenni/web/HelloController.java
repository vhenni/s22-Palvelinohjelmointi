package s22.FirstHenni.web;

import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {

	@RequestMapping("hello")
	@ResponseBody
	public String indexInfo () {
		String location_value = "moon";
		String name_value = "John";
		return "Welcome to the " + location_value + " "+ name_value +"!";
	}
}
